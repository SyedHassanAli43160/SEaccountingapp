﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class addloan : Form
    {
        public addloan()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (addclient ac = new addclient())
            {
                ac.ShowDialog();
            }
        }
      

        public string fileName1;
        public string contentType;
        public byte[] bytes;
        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string ecn = existingclientname.Text;
            string iq = itemquantity.Text; 
            string amnt = amount.Text;          
            string ait = Convert.ToString(Convert.ToInt32(amount.Text) * Convert.ToInt32(itemquantity.Text));
            string desc = description.Text;
            if (existingclientname.Text != "" && itemquantity.Text != "" && amount.Text != "" && description.Text != "")
            {              
                              
              string query = "INSERT INTO addloan (name,itemquantity,amount,amountintotal,date,description) VALUES ('" + ecn + "','" + iq + "','" + amnt + "','" + ait + "','" + dateTimePicker1.Value.Date + "','" + desc + "')";


                    int result = dc.ExecuteNonQuery(query);

                    if (result > 0)
                    {
                        MessageBox.Show("Data Inserted");
                        existingclientname.Text = itemquantity.Text = amount.Text = amountintotal.Text =description.Text= "";
                        this.Close();
                    }
                
                else
                {
                    MessageBox.Show("Data is not Inserted");
                }

            }
        }
    

        private void AddNewBook_Load(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from loanprovider";
            MySqlDataReader row;
            row = dc.ExecuteReader(query);
            if (row.HasRows)
            {
                while (row.Read())
                {
                    existingclientname.Items.Add(row["name"]);
                }
                dc.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string iq = itemquantity.Text;
                string amnt = amount.Text;
                string ait = Convert.ToString(Convert.ToInt32(amount.Text) * Convert.ToInt32(itemquantity.Text));
                amountintotal.Text = ait;
            }
            catch(Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            addloanprovider alp = new addloanprovider();
            alp.Show();
            this.Hide();
        }
    }

       
    
}
