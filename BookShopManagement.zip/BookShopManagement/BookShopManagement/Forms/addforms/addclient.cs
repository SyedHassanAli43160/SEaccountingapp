﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class addclient : Form
    {
        public addclient()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            if (clientname.Text != "" && clientaddress.Text != "" && clientgst.Text!="" && clientntn.Text!="")
            {
               
                string name = clientname.Text;
                string address = clientaddress.Text;
                string gst = clientgst.Text;
                string ntn = clientntn.Text;
                string query = "INSERT INTO client (clientname,clientntn,clientgst,clientaddress) VALUES ('" + name + "','" + ntn + "','" + gst + "','" + address + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    clientname.Text = clientaddress.Text=clientgst.Text=clientntn.Text = "";
                }

                else
                {
                    MessageBox.Show("Data is not Inserted");
                }

            }
        }
    }
}
