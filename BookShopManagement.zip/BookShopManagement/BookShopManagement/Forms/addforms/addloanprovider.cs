﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class addloanprovider : Form
    {
        public addloanprovider()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            if (catlp.Text != "" && lpname.Text != ""  && txtdescription.Text != "")
            {
                string category = catlp.Text;
                string loanprovider = lpname.Text;
               
                string desc = txtdescription.Text;
                string phoneno=txtpn.Text;
                
                    string query = "INSERT INTO loanprovider (category,name,description,phoneNo) VALUES ('" +category + "','" + loanprovider + "','" + desc + "','" + phoneno + "')";


                    int result = dc.ExecuteNonQuery(query);

                    if (result > 0)
                    {
                        MessageBox.Show("Data Inserted");
                        catlp.Text = lpname.Text  = txtdescription.Text =txtpn.Text = "";
                        this.Close();
                    }
               
                else
                {
                    MessageBox.Show("Data is not Inserted");
                }

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void catlp_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void addloanprovider_Load(object sender, EventArgs e)
        {

        }
    }
}
