﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class UpdateBook2 : Form
    {
        public string epubName;
        public UpdateBook2(string epubName1)
        {
            this.epubName = epubName1;
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (addclient ac = new addclient())
            {
                ac.ShowDialog();
            }
        }
        string saveDirectory = @"C:\Users\Bytes-02\source\repos\BookShopManagement\BookShopManagement\Cover Pages";
        string fileSavePath;
        string fileName;
        OpenFileDialog fdlg = new OpenFileDialog();
        private void button2_Click_1(object sender, EventArgs e)
        {
            
            fdlg.Title = "C# Corner Open File Dialog";
            fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "png files (*.png*)|*.*|jpg files (*.jpg*)|*.*|jpeg files (*.jpeg*)|*.*|All files (*.*)|*.*";
        
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
               
                //pictureBox1.Image = Image.FromFile(fdlg.FileName);
                fileName = Path.GetFileName(fdlg.FileName);
                lblcp.Text = fileName;
                // MessageBox.Show(fileName);
                fileSavePath = Path.Combine(saveDirectory, fileName);
            }
           

        }

        public string fileName1;
        public string contentType;
        public byte[] bytes;
        private void button5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    fileName1 = openFileDialog1.FileName;
                    bytes = File.ReadAllBytes(fileName1);
                    contentType = "";
                    //Set the contenttype based on File Extension

                    switch (Path.GetExtension(fileName1))
                    {
                        case ".jpg":
                            contentType = "image/jpeg";
                            break;
                        case ".png":
                            contentType = "image/png";
                            break;
                        case ".gif":
                            contentType = "image/gif";
                            break;
                        case ".bmp":
                            contentType = "image/bmp";
                            break;
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // MemoryStream ms = new MemoryStream();
           // pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
          //  byte[] img = ms.ToArray();
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string sql = "INSERT INTO book (bookName, coverPage , categoryID , authorName , details) VALUES(@nameBook,@pageCover,@iDcategory, @nameAuthor , @bookDetails)";
            using (MySqlCommand cmd = new MySqlCommand(sql, dc.conn))
            {
                cmd.Parameters.Add("@nameBook", MySqlDbType.VarChar,50);
                // cmd.Parameters.AddWithValue("@nameBook", bookName.Text);
                cmd.Parameters.Add("@pageCover", MySqlDbType.VarChar,50);
                // cmd.Parameters.AddWithValue("@pageCover", lblcp.Text);
                cmd.Parameters.Add("@iDcategory", MySqlDbType.Int32);
                //cmd.Parameters.AddWithValue("@iDcategory", bookCategory.Text);
                cmd.Parameters.Add("@nameAuthor", MySqlDbType.VarChar, 50);
                // cmd.Parameters.AddWithValue("@nameAuthor", authorName.Text);
                cmd.Parameters.Add("@bookDetails", MySqlDbType.VarChar, 50);
                //cmd.Parameters.AddWithValue("@bookDetails", description.Text);

                cmd.Parameters["@nameBook"].Value = bookName.Text;
                cmd.Parameters["@pageCover"].Value = lblcp.Text;
                cmd.Parameters["@iDcategory"].Value = bookCategory.Text;
                cmd.Parameters["@nameAuthor"].Value = authorName.Text;
                cmd.Parameters["@bookDetails"].Value = description.Text;


               // cmd.Prepare();

               


               
               // cmd.Parameters.AddWithValue("@Data", bytes);
               
                if(cmd.ExecuteNonQuery() == 1)
                {
                    File.Copy(fdlg.FileName, fileSavePath, true);
                    MessageBox.Show("Book Added");
                }
                dc.Close();
            }
        }

        private void UpdateBook2_Load(object sender, EventArgs e)
        {
            bookName.Text = epubName;

            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from book";
            MySqlDataReader row;
            row = dc.ExecuteReader(query);
            if (row.HasRows)
            {
                
            }
        }
    }

       
    
}
