﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BookShopManagement.Forms.addforms;
using MySql.Data.MySqlClient;

namespace BookShopManagement.UserControls
{
    public partial class manageexp : UserControl
    {
        public manageexp()
        {
            InitializeComponent();
        }

        private void btnaddexp_Click(object sender, EventArgs e)
        {
            addexp ae = new addexp();
            ae.Show();
        }

        private void manageexp_Load(object sender, EventArgs e)
        {

            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from monthlyexp";
            MySqlDataAdapter da = new MySqlDataAdapter(query, dc.conn);
            DataTable ds = new DataTable();
            da.Fill(ds);
            dataGridView1.DataSource = ds;
            dc.Close();
        }
    }
}
