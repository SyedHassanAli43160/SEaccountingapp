﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BookShopManagement.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace BookShopManagement.UserControls
{
    public partial class manageloan : UserControl
    {
        public manageloan()
        {
            InitializeComponent();
        }


        private void managebooks_Load(object sender, EventArgs e)
        {

            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from addloan";
            MySqlDataAdapter da = new MySqlDataAdapter(query, dc.conn);
            DataTable ds = new DataTable();
            da.Fill(ds);
            dataGridView1.DataSource = ds;
            dc.Close();

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddNewBooks_Click(object sender, EventArgs e)
        {
            addloan al = new addloan();
            al.Show();
        }

        private void btnpaidloan_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
           foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
            {
                try
                {
                    if (oneCell.Selected)
                    {
                        if (dc.Open())
                        {
                            string name = dataGridView1.Rows[oneCell.RowIndex].Cells[0].Value.ToString();
                            MySqlDataAdapter sqd = new MySqlDataAdapter("DELETE FROM addloan WHERE loanid='" + name + "'", dc.conn);
                            string query = "INSERT INTO paidloan SELECT * FROM addloan WHERE loanid='"+name+"'";

                            int result = dc.ExecuteNonQuery(query);


                            DataTable dt = new DataTable();
                            dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
                            sqd.Fill(dt);
                            MessageBox.Show("Data inserted into paid loan section");
                            dc.Close();
                        }

                        else
                        {
                            MessageBox.Show("Please select Any Row");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }

                
            }
        }

        private void btnviewpaidloan_Click(object sender, EventArgs e)
        {
            viewpaidloan vpl = new viewpaidloan();
            vpl.Show();
        }
    }
}
