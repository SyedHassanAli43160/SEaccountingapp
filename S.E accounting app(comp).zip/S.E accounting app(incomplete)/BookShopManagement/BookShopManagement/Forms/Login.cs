﻿using BookShopManagement.Forms;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ConnectionDB dc = new ConnectionDB();
                dc.Open();

                if (txtunamelogin.Text != "" && txtpasslogin.Text != "")
                {
                    string query = "select * from admin where adminid='" + txtunamelogin.Text + "' AND password='" + txtpasslogin.Text + "'";
                    MySqlDataReader row;
                    row = dc.ExecuteReader(query);
                    if (row.HasRows)
                    {
                        admin_Dashboard ad = new admin_Dashboard();
                        ad.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("You're giving wrong info");
                    }
                    dc.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            

        }

      
        private void label7_Click_1(object sender, EventArgs e)
        {
            var myform = new registeration();
            myform.Show();
        }

        
    }
}
