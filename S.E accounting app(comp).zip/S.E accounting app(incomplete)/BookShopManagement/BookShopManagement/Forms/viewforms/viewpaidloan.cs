﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class viewpaidloan : Form
    {
        public viewpaidloan()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void viewpaidloan_Load(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from paidloan";
            MySqlDataAdapter da = new MySqlDataAdapter(query, dc.conn);
            DataTable ds = new DataTable();
            da.Fill(ds);
            dataGridView1.DataSource = ds;
            dc.Close();
        }

      
       

       

        private void button3_Click_1(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            foreach (DataGridViewCell oneCell in dataGridView1.SelectedCells)
            {
                try
                {
                    if (oneCell.Selected)
                    {
                        if (dc.Open())
                        {
                            string name = dataGridView1.Rows[oneCell.RowIndex].Cells[0].Value.ToString();
                            MySqlDataAdapter sqd = new MySqlDataAdapter("DELETE FROM paidloan WHERE loanid='" + name + "'", dc.conn);
                            DataTable dt = new DataTable();
                            dataGridView1.Rows.RemoveAt(oneCell.RowIndex);
                            sqd.Fill(dt);
                            MessageBox.Show("Data Deleted Successfully");
                            dc.Close();
                        }

                        else
                        {
                            MessageBox.Show("Please select Any Row");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
