﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addbankwithdrawdetails : Form
    {
        public addbankwithdrawdetails()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string name = txtname.Text;
            string desc = txtdesc.Text;
            string amount = txtamount.Text;
            string chequeno = txtchequeno.Text;
            string bank = txtbankname.Text;

            string query = "INSERT INTO withdrawfrombank (Name,Description,Amount,ChequeNo,Date,BankName) VALUES ('" + name + "','" + desc + "','" + amount + "','" + chequeno + "','" + dateTimePicker1.Value.Date + "','" + bank + "')";


            int result = dc.ExecuteNonQuery(query);

            if (result > 0)
            {
                MessageBox.Show("Data Inserted");
                txtname.Text = txtdesc.Text =txtamount.Text = txtchequeno.Text =txtbankname.Text ="";
            }

            else
            {
                MessageBox.Show("Data is not Inserted");
            }


            this.Close();
        }
    }
}
