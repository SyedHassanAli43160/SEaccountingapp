﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addinvester : Form
    {
        public addinvester()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            if (txtinvestername.Text != "" && txtinvestoremail.Text != "" && txtphoneno.Text != "" && txtdesc.Text != "")
            {

                string name = txtinvestername.Text;
                string email = txtinvestoremail.Text;
                string phone = txtphoneno.Text;
                string desc = txtdesc.Text;
                string query = "INSERT INTO investor(Name,Email,Phone,Description) VALUES ('" + name + "','" + email + "','" + phone + "','" + desc + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    txtinvestername.Text = txtinvestoremail.Text = txtphoneno.Text = txtdesc.Text = "";
                }

                else
                {
                    MessageBox.Show("Data is not Inserted");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
