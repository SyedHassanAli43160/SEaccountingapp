﻿using BookShopManagement.Forms.viewforms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addbankdepositdetail : Form
    {
        public addbankdepositdetail()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string name = txtname.Text;
            string desc = txtdesc.Text;
            string cat = comboBox1.Text;
            string amount = txtamount.Text;
            string chequeno = txtchequeno.Text;
            string bank = txtbankname.Text;
            if (txtname.Text!="" && txtdesc.Text!="" && comboBox1.Text!="" && txtamount.Text!="" && txtchequeno.Text!="" && txtbankname.Text!="") 
            {
                string query = "INSERT INTO depositintobank (Name,Category,Description,Amount,ChequeNo,Date,Bank) VALUES ('" + name + "','" + cat + "','" + desc + "','" + amount + "','" + chequeno + "','" + dateTimePicker1.Value.Date + "','" + bank + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    txtname.Text = txtdesc.Text = txtamount.Text = txtchequeno.Text = txtbankname.Text = "";
                }

                else
                {
                    MessageBox.Show("Data is not Inserted");
                }

            }
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            viewdepositdetails vdd = new viewdepositdetails();
            vdd.Show();
        }

        private void txtbankname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
