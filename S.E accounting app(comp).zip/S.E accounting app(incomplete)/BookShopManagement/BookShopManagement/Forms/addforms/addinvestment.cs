﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addinvestment : Form
    {
        public addinvestment()
        {
            InitializeComponent();
        }

        private void addinvester_Load(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from investor";
            MySqlDataReader row;
            row = dc.ExecuteReader(query);
            if (row.HasRows)
            {
                while (row.Read())
                {
                    txtinvestername.Items.Add(row["Name"]);
                }
                dc.Close();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string name = txtinvestername.Text;
            string expense = txtexpense.Text;
            string saleamount = txtsa.Text;
            string gst = txt17percent.Text;        
            string recieveamount =txtrecieveamount.Text;
            string nineteen =txt19.Text;
            string profit =txtprofit.Text;
            string investerprofit =txtinvesterprofit.Text;
            string cname =txtcompanyname.Text;
            string invoiceno =txtinvoiceno.Text;
            string desc =txtdescription.Text;
            if (txtinvestername.Text != "" && txtexpense.Text != "" && txtsa.Text != "" && txt17percent.Text != "" && txtrecieveamount.Text!="" && txt19.Text!="" && txtprofit.Text!=""&& txtinvesterprofit.Text!="" && txtcompanyname.Text!="" && txtinvoiceno.Text!="" && txtdescription.Text!="")
            {

                string query = "INSERT INTO investment (Name,Expense,Saleamount,seventeenper,Recievedamount,minusninteen,profit,Investerprofit,CompanyName,InvoiceNo,Date,Description) VALUES ('" + name + "','" +expense + "','" + saleamount + "','" + gst + "','" + recieveamount + "','" + nineteen + "','" + profit + "','" + investerprofit + "','" + cname + "','" + invoiceno + "','" + dateTimePicker1.Value.Date + "','" + desc + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    txtinvestername.Text = txtexpense.Text = txtsa.Text = txt17percent.Text = txtrecieveamount.Text =txt19.Text=txtprofit.Text=txtinvesterprofit.Text=txtcompanyname.Text=txtinvoiceno.Text=txtdescription.Text ="";
                    this.Close();
                }

                else
                {
                    MessageBox.Show("Data is not Inserted ");
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnshowdetails_Click(object sender, EventArgs e)
        {
            try
            {
                string sevenper = (((Convert.ToInt32(txtsa.Text) * 17) / 100).ToString());
                txt17percent.Text = sevenper;
                string ramount = Convert.ToString(Convert.ToInt32(txt17percent.Text) + Convert.ToInt32(txtsa.Text));
                txtrecieveamount.Text = ramount;
                double ninteenper = (Convert.ToDouble(txtrecieveamount.Text) * 19.03) / 100;
                string minus19 = Convert.ToString(Convert.ToInt32(txtrecieveamount.Text) - Convert.ToInt32(ninteenper));
                txt19.Text = minus19;
                double profit = Convert.ToDouble(minus19) - Convert.ToDouble(txtexpense.Text);
                txtprofit.Text = profit.ToString();
                //string check = txtinvesterprofit.Text();
                double invprofit = (Convert.ToDouble(txtprofit.Text) * Convert.ToDouble(txtprofitper.Text)) / 100;
                txtinvesterprofit.Text = invprofit.ToString();
                btnadd.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
            }
        }

        private void lbladdinvester_Click(object sender, EventArgs e)
        {
            addinvester ai = new addinvester();
            ai.Show();
        }

        private void txtsa_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
