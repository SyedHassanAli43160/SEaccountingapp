﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addexp : Form
    {
        public addexp()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Cash")
            {
                lbltype1.Visible = true;
                txttypecash.Visible = true;
                lbltype1.Text = "Enter Amount";
                lbltype.Visible = false;
                txttypecheque.Visible = false;
               
            }
            else if (comboBox1.Text == "Cheque")
            {
                lbltype.Visible = true;
                lbltype1.Visible = true;
                txttypecheque.Visible = true;
                txttypecash.Visible = true;
                lbltype1.Text = "Enter Amount";
                lbltype.Text = "Enter Cheque NO:";
            }
            else
            {
                lbltype.Visible = false;
                lbltype1.Visible = false;
                txttypecheque.Visible = false;
                txttypecash.Visible = false;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void btnsave_Click_1(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
                string ename = expname.Text;
                string etype = comboBox1.Text;
                string eptype = txttypecash.Text;
                string epctype = txttypecheque.Text;
                string desc = txtdesc.Text;

                string query = "INSERT INTO monthlyexp (ExpName,Description,amount,ChequeNo,Paymenttype,Date) VALUES ('" + ename + "','" + desc + "','" + eptype + "','" + epctype + "','" + etype + "','" + dateTimePicker1.Value.Date + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    expname.Text = comboBox1.Text = txttypecash.Text = txtdesc.Text = "";
                }

                else
                {
                    MessageBox.Show("Data is not Inserted");
                }
                
            
            this.Close();
        }

        private void addexp_Load(object sender, EventArgs e)
        {

        }
    }
}
