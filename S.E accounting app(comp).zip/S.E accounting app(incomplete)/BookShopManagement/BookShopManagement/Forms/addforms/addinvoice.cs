﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms.addforms
{
    public partial class addinvoice : Form
    {
        public addinvoice()
        {
            InitializeComponent();
        }

        private void lbladdclient_Click(object sender, EventArgs e)
        {
            addclient ac = new addclient();
            ac.Show();
            this.Close();
        }

        private void addinvoice_Load(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from client";
            MySqlDataReader row;
            row = dc.ExecuteReader(query);
            if (row.HasRows)
            {
                while (row.Read())
                {
                    cnamecb.Items.Add(row["clientname"]);
                }
                dc.Close();
            }
        }

        private void cnamecb_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string query = "select * from client Where clientname='" + cnamecb.Text + "'";
            MySqlDataReader row;
            row = dc.ExecuteReader(query);
            if (row.HasRows)
            {
                while (row.Read())
                {
                    string ntn = (string)row["clientntn"];
                    string gst = (string)row["clientgst"];
                    txtntnno.Text = ntn;
                    txtgstno.Text = gst;
                }
                dc.Close();
            }
        }

        private void btnshowdetails_Click(object sender, EventArgs e)
        {
            try
            {
                string tprice = Convert.ToString(Convert.ToInt32(txtunitprice.Text) * Convert.ToInt32(txtquantity.Text));
                txttotalITEMprice.Text = tprice;
                if (gstcb.Text == "13%")
                {
                    string thirteenper = (((Convert.ToInt32(txttotalITEMprice.Text) * 13) / 100).ToString());
                    string tper = Convert.ToString(Convert.ToInt32(thirteenper) + Convert.ToInt32(txttotalITEMprice.Text));
                    txtotalINCLGST.Text = tper;
                    btnadd.Visible = true;
                }
                else if (gstcb.Text == "17%")
                {
                    string seventeenper = (((Convert.ToInt32(txttotalITEMprice.Text) * 17) / 100).ToString());
                    string tper = Convert.ToString(Convert.ToInt32(seventeenper) + Convert.ToInt32(txttotalITEMprice.Text));
                    txtotalINCLGST.Text = tper;
                    btnadd.Visible = true;
                }
                else
                {
                    btnadd.Visible = false;
                    MessageBox.Show("Please Select GST%");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            string name = cnamecb.Text;
            string ntn = txtntnno.Text;
            string gst = txtgstno.Text;
            string description = txtdescription.Text;
            string uprice = txtunitprice.Text;
            string itemquantity = txtquantity.Text;
            string titemprice = txttotalITEMprice.Text;
            string gsttype = gstcb.Text;
            string tinclgst = txtotalINCLGST.Text;
            string invoice = txtinvoiceno.Text;
            if (cnamecb.Text != "" && txtntnno.Text != "" && txtgstno.Text != "" && txtdescription.Text != "" && txtunitprice.Text != "" && txtquantity.Text != "" && txttotalITEMprice.Text != "" && gstcb.Text != "" && txtotalINCLGST.Text != "" && txtinvoiceno.Text != "")
            {

                string query = "INSERT INTO invoice (ClientName,NTNno,GSTNo,Description,Date,UnitPrice,ItemQuantity,TotalItemPrice,GST,TotalInclGST,InvoiceNo) VALUES ('" + name + "','" + ntn + "','" + gst + "','" + description + "','" + dateTimePicker1.Value.Date + "','" + uprice + "','" + itemquantity + "','" + titemprice + "','" + gsttype + "','" + tinclgst + "','" + invoice + "')";


                int result = dc.ExecuteNonQuery(query);

                if (result > 0)
                {
                    MessageBox.Show("Data Inserted");
                    cnamecb.Text = txtntnno.Text = txtgstno.Text = txtdescription.Text = txtunitprice.Text = txtquantity.Text = txttotalITEMprice.Text = gstcb.Text = txtotalINCLGST.Text = txtinvoiceno.Text = "";
                    this.Close();
                }

                else
                {
                    MessageBox.Show("Data is not Inserted ");
                }

            }
        }
    }
}
