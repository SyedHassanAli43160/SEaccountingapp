﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagement.Forms
{
    public partial class registeration : Form
    {
        public registeration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB dc = new ConnectionDB();
            dc.Open();
            if (reguname.Text != "" && regemail.Text != "" && regpass.Text != "" && regcpass.Text != "")
            {
                string uid = reguname.Text;
                string email = regemail.Text;
                string pass = regpass.Text;
                string dob = regdob.Text;
                //string pn = regphone.Text;
                if (regpass.Text == regcpass.Text)
                {
                    string query = "INSERT INTO admin(adminid,password,email,dob) VALUES ('" + uid + "','" + pass + "','" + email + "','" + dob + "')";


                    int result = dc.ExecuteNonQuery(query);

                    if (result > 0)
                    {
                        MessageBox.Show("Data Inserted");
                        reguname.Text = regemail.Text = regpass.Text =  "";
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Data is not Inserted");
                }

            }
        }
    }
}
