﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BookShopManagement.UserControls
{
    public partial class UC_Home : UserControl
    {
        public UC_Home()
        {
            InitializeComponent();
        }
        Random rand = new Random();

        private void LoadChart()
        {
            var cnv = new Bunifu.DataViz.Canvas();
            var dataPoint = new Bunifu.DataViz.DataPoint(Bunifu.DataViz.BunifuDataViz._type.Bunifu_splineArea);

            dataPoint.addLabely("Jan",rand.Next(0,500).ToString());
            dataPoint.addLabely("Feb", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Mar", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Apr", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Jun", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Jul", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Aug", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Sep", rand.Next(0, 500).ToString());
            dataPoint.addLabely("Oct", rand.Next(0, 500).ToString());

            cnv.addData(dataPoint);



        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadChart();
        }
        ConnectionDB dc = new ConnectionDB();
        private void UC_Home_Load(object sender, EventArgs e)
        {
            
            dc.Open();
            string query = "select * from loanprovider";
            MySqlDataAdapter da = new MySqlDataAdapter(query, dc.conn);
            DataTable ds = new DataTable();
            da.Fill(ds);
            dataGridView1.DataSource = ds;
            dc.Close();
            dc.Open();
            string qury = "SELECT * FROM investment";
            MySqlCommand cmd = new MySqlCommand(qury, dc.conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            int count = 0;
            while (rdr.Read())
            {
                count++;
            }
            lblinvester.Text = count.ToString();
            dc.Close();
            dc.Open();
            string qry = "SELECT * FROM client";
            MySqlCommand cd = new MySqlCommand(qry, dc.conn);
            MySqlDataReader readr = cd.ExecuteReader();
            int cont = 0;
            while (readr.Read())
            {
                cont++;
            }
            lbltotalclient.Text = cont.ToString();
            dc.Close();
            dc.Open();
            string quury = "SELECT * FROM addloan";
            MySqlCommand cmmd = new MySqlCommand(quury, dc.conn);
            MySqlDataReader rddr = cmmd.ExecuteReader();
            int coount = 0;
            while (rddr.Read())
            {
                coount++;
            }
            lblloaners.Text = coount.ToString();
            dc.Close();
            dc.Open();
            string quuury = "SELECT * FROM invoice";
            MySqlCommand cmmmd = new MySqlCommand(quuury, dc.conn);
            MySqlDataReader rdrr = cmmmd.ExecuteReader();
            int ccount = 0;
            while (rdrr.Read())
            {
                ccount++;
            }
            lblinvoice.Text = ccount.ToString();
            dc.Close();
        }
    }
}
