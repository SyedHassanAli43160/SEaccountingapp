-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2021 at 04:35 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `addloan`
--

CREATE TABLE `addloan` (
  `loanid` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `itemquantity` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `amountintotal` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addloan`
--

INSERT INTO `addloan` (`loanid`, `name`, `itemquantity`, `amount`, `amountintotal`, `date`, `description`) VALUES
(9, 'hasnu', '2', '100', '200', '6/24/2021 12:00:00 AM', 'asdasddsaaa');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `password`, `email`, `dob`) VALUES
('asd', 'asd', 'asd', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `clientid` int(11) NOT NULL,
  `clientname` varchar(50) NOT NULL,
  `clientntn` varchar(50) NOT NULL,
  `clientgst` varchar(50) NOT NULL,
  `clientaddress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`clientid`, `clientname`, `clientntn`, `clientgst`, `clientaddress`) VALUES
(7, 'hasnu', '12345', '90', 'idk');

-- --------------------------------------------------------

--
-- Table structure for table `depositintobank`
--

CREATE TABLE `depositintobank` (
  `Id` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `ChequeNO` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Bank` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `investment`
--

CREATE TABLE `investment` (
  `ID` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Expense` varchar(50) NOT NULL,
  `Saleamount` varchar(50) NOT NULL,
  `seventeenper` varchar(50) NOT NULL,
  `Recievedamount` varchar(50) NOT NULL,
  `minusninteen` varchar(50) NOT NULL,
  `profit` varchar(50) NOT NULL,
  `Investerprofit` varchar(50) NOT NULL,
  `CompanyName` varchar(50) NOT NULL,
  `InvoiceNo` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investment`
--

INSERT INTO `investment` (`ID`, `Name`, `Expense`, `Saleamount`, `seventeenper`, `Recievedamount`, `minusninteen`, `profit`, `Investerprofit`, `CompanyName`, `InvoiceNo`, `Date`, `Description`) VALUES
(3, 'Hasssssaaaaaannnnn', '200', '400', '68', '468', '379', '179', '89.5', 'asddsa', '2333', '6/24/2021 12:00:00 AM', 'asdadasdasdassdasd');

-- --------------------------------------------------------

--
-- Table structure for table `investor`
--

CREATE TABLE `investor` (
  `ID` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investor`
--

INSERT INTO `investor` (`ID`, `Name`, `Email`, `Phone`, `Description`) VALUES
(3, 'Hasssssaaaaaannnnn', 'hasan123.com', '123321123321', 'asdasdasdas');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `ID` int(50) NOT NULL,
  `ClientName` varchar(50) NOT NULL,
  `NTNno` varchar(50) NOT NULL,
  `GSTNo` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `UnitPrice` varchar(50) NOT NULL,
  `ItemQuantity` varchar(50) NOT NULL,
  `TotalItemPrice` varchar(50) NOT NULL,
  `GST` varchar(50) NOT NULL,
  `TotalInclGST` varchar(50) NOT NULL,
  `InvoiceNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`ID`, `ClientName`, `NTNno`, `GSTNo`, `Description`, `Date`, `UnitPrice`, `ItemQuantity`, `TotalItemPrice`, `GST`, `TotalInclGST`, `InvoiceNo`) VALUES
(3, 'hasnu', '12345', '90', 'asdads', '6/24/2021 12:00:00 AM', '200', '2', '400', '17%', '468', '2211');

-- --------------------------------------------------------

--
-- Table structure for table `loanprovider`
--

CREATE TABLE `loanprovider` (
  `id` int(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `phoneNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loanprovider`
--

INSERT INTO `loanprovider` (`id`, `category`, `name`, `amount`, `description`, `phoneNo`) VALUES
(7, 'Other', 'hasnu', '', 'ohoooo', '033333333');

-- --------------------------------------------------------

--
-- Table structure for table `monthlyexp`
--

CREATE TABLE `monthlyexp` (
  `id` int(50) NOT NULL,
  `ExpName` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `ChequeNo` varchar(50) NOT NULL,
  `Paymenttype` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `paidloan`
--

CREATE TABLE `paidloan` (
  `loanid` varchar(1000) NOT NULL,
  `name` varchar(50) NOT NULL,
  `itemquantity` varchar(255) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `amountintotal` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paidloan`
--

INSERT INTO `paidloan` (`loanid`, `name`, `itemquantity`, `amount`, `amountintotal`, `date`, `description`) VALUES
('8', 'hasnu', '88', '45', '3960', '6/22/2021 12:00:00 AM', 'shi h');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawfrombank`
--

CREATE TABLE `withdrawfrombank` (
  `Id` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Amount` varchar(50) NOT NULL,
  `ChequeNo` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `BankName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addloan`
--
ALTER TABLE `addloan`
  ADD PRIMARY KEY (`loanid`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`clientid`);

--
-- Indexes for table `depositintobank`
--
ALTER TABLE `depositintobank`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `investment`
--
ALTER TABLE `investment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `investor`
--
ALTER TABLE `investor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `loanprovider`
--
ALTER TABLE `loanprovider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthlyexp`
--
ALTER TABLE `monthlyexp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawfrombank`
--
ALTER TABLE `withdrawfrombank`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addloan`
--
ALTER TABLE `addloan`
  MODIFY `loanid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `clientid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `depositintobank`
--
ALTER TABLE `depositintobank`
  MODIFY `Id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `investment`
--
ALTER TABLE `investment`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `investor`
--
ALTER TABLE `investor`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `loanprovider`
--
ALTER TABLE `loanprovider`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `monthlyexp`
--
ALTER TABLE `monthlyexp`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `withdrawfrombank`
--
ALTER TABLE `withdrawfrombank`
  MODIFY `Id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
